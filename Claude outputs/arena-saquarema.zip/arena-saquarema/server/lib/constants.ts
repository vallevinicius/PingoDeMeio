export const COOKIE_NAME = 'arena_token';
